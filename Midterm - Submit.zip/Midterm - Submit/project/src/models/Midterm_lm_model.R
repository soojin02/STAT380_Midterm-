library(caret)
library(data.table)
library(Metrics)
library(dplyr)
library(tidyverse)

# Load data
train <- fread("./project/volume/data/raw/Stat_380_train.csv")
test <- fread("./project/volume/data/raw/Stat_380_test.csv")
covar <- fread("./project/volume/data/raw/covar_data.csv")
example_sub <- fread("./project/volume/data/raw/Example_Sub.csv")

#lm_model with data that is needed/ has most info.
lm_model <- lm(ic50_Omicron ~ age + centre + dose_2 + dose_3  + priorSxAtFirstVisit + priorSxAtFirstVisitSeverity + days_sinceDose2  + days_dose12interval + posTest_beforeVisit, data = train)
summary(lm_model)
# Save the linear regression model
saveRDS(lm_model, "./project/volume/data/processed/lm_model")

test$ic50_Omicron <- predict(lm_model, newdata = test)
submit <- select(test, sample_id, ic50_Omicron)

#Save csv
fwrite(submit, "./project/volume/data/processed/submit_lm_1.csv")
